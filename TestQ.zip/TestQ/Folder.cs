﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace PlayerUI
{
    /// <summary>
    /// Класс папка
    /// </summary>
    public class Folder : IShell
    {
        /// <summary>
        /// Поле путь
        /// </summary>
        private string _path = "";

        /// <summary>
        /// Поле искомых расширений
        /// </summary>
        private string _extensions = "";

        /// <summary>
        /// Поле файлов
        /// </summary>
        private IEnumerable<string> _files = null;

        /// <summary>
        /// Свойство для пути
        /// </summary>
        public string Path
        {
            get { return _path; }
            set { if (value != null) _path = value; }
        }

        /// <summary>
        /// Свойство искомых расширений
        /// </summary>
        public string Extensions
        {
            get { return _extensions; }
            set { if (value != null) _extensions = value; }
        }

        /// <summary>
        /// Искомые файлы
        /// </summary>
        public IEnumerable<string> Files
        {
            get { return _files; }
            set { if (value != null) _files = value; }
        }

        /// <summary>
        /// Метод для поиска искомых файлов по необходимым параметрам
        /// </summary>
        /// <param name="path">путь</param>
        /// <param name="searchPatternExpression">расширения</param>
        /// <param name="searchOption">Опция поиска</param>
        /// <returns></returns>
        public IEnumerable<string> NGetFiles(string path, string searchPatternExpression, SearchOption searchOption = SearchOption.AllDirectories)
        {
            Regex reSearchPattern = new Regex(searchPatternExpression);
            return Directory.EnumerateFiles(path, "*", searchOption).Where(file => reSearchPattern.IsMatch(System.IO.Path.GetFileName(file)));
        }

        /// <summary>
        /// Метод реализующий поиск необходимых искомых файлов
        /// </summary>
        public void SearchAllFiles()
        {
            Files = NGetFiles(Path, Extensions);
        }

    }
}
