﻿using System.Collections.Generic;
using System.IO;

namespace PlayerUI
{
    /// <summary>
    /// Интерфейс оболочки
    /// </summary>
    interface IShell
    {
        /// <summary>
        /// Свойство для получения пути
        /// </summary>
        string Path { get; set; }

        /// <summary>
        /// Искомые расширения
        /// </summary>
        string Extensions { get; set; }

        /// <summary>
        /// Список необходимых файлов
        /// </summary>
        IEnumerable<string> Files { get; set; }

        /// <summary>
        /// Метод для реализации поиска
        /// </summary>
        /// <param name="path">путь</param>
        /// <param name="searchPatternExpression">искомые расширения</param>
        /// <param name="searchOption">Параметры поика</param>
        /// <returns></returns>
        IEnumerable<string> NGetFiles(string path, string searchPatternExpression, SearchOption searchOption = SearchOption.AllDirectories);
    }
}
