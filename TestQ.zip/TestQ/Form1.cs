﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace PlayerUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            hideSubMenu();
        }

        private void hideSubMenu()
        {
            panelMemuSubMenu.Visible = false;
        }

        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }

        private void btnFile_Click(object sender, EventArgs e)
        {
            showSubMenu(panelMemuSubMenu);
        }

        private void btnFolder_Click(object sender, EventArgs e)
        {
            treeView.Nodes.Clear();

            using (FolderBrowserDialog fbd = new FolderBrowserDialog())
            {
                DialogResult result = fbd.ShowDialog();

                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
                {

                    Folder folder = new Folder
                    {
                        Path = fbd.SelectedPath,
                        Extensions = "\\.png|\\.gif|\\.tiff|\\.jpg|\\.jpeg|\\.bmp",
                    };

                    folder.SearchAllFiles();

                    foreach (string f in folder.Files)
                    {
                        if (File.Exists(f))
                        {
                            treeView.Nodes.Add(f);
                        }  
                    }
                }
            }

            hideSubMenu();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void treeView_AfterSelect(object sender, TreeViewEventArgs e)
        {
            pictureBox.Image = new Bitmap(treeView.SelectedNode.FullPath);
        }
    }
}
